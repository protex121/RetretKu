package com.example.retretku;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class classReportAdapter extends RecyclerView.Adapter<classReportAdapter.ReportViewHolder> {
    private Context context;
    private ArrayList<classReport> listReport;

    public classReportAdapter(Context context, ArrayList<classReport> listReport) {
        this.context = context;
        this.listReport = listReport;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.report_detail,parent,false);
        ReportViewHolder holder = new ReportViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        classReport report = listReport.get(position);
        holder.tvBy.setText(report.getReportBy() + ", " + report.getDate());
        holder.tvText.setText(report.getReportText());
    }

    @Override
    public int getItemCount() {
        return listReport.size();
    }

    public class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView tvBy, tvText;
        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBy = itemView.findViewById(R.id.tvReportBy);
            tvText = itemView.findViewById(R.id.tvReportText);
        }
    }
}
