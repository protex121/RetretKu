package com.example.retretku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class report extends AppCompatActivity {
    ArrayList<classReport> listReport;
    RecyclerView rvReport;
    classReportAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        rvReport = findViewById(R.id.rvReport);
        listReport = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, HH:mm");
        String date = sdf.format(new Date());
        listReport.add(new classReport("Andi","Rumah retret B kotor",date));
        listReport.add(new classReport("Budi","Penjaga rumah retret A tidak ramah",date));
        listReport.add(new classReport("Charles","Makanan rumah retret C tidak enak",date));

        rvReport.setHasFixedSize(true);
        adapter = new classReportAdapter(this,listReport);
        rvReport.setLayoutManager(new LinearLayoutManager(this));
        rvReport.setAdapter(adapter);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
