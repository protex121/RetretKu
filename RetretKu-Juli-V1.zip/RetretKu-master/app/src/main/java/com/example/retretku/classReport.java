package com.example.retretku;

import android.os.Parcel;
import android.os.Parcelable;

public class classReport implements Parcelable {
    private String reportBy, reportText, date;

    public classReport(String reportBy, String reportText, String date) {
        this.reportBy = reportBy;
        this.reportText = reportText;
        this.date = date;
    }

    protected classReport(Parcel in) {
        reportBy = in.readString();
        reportText = in.readString();
        date = in.readString();
    }

    public static final Creator<classReport> CREATOR = new Creator<classReport>() {
        @Override
        public classReport createFromParcel(Parcel in) {
            return new classReport(in);
        }

        @Override
        public classReport[] newArray(int size) {
            return new classReport[size];
        }
    };

    public String getReportBy() {
        return reportBy;
    }

    public void setReportBy(String reportBy) {
        this.reportBy = reportBy;
    }

    public String getReportText() {
        return reportText;
    }

    public void setReportText(String reportText) {
        this.reportText = reportText;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(reportBy);
        parcel.writeString(reportText);
        parcel.writeString(date);
    }
}
