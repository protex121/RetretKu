<h1><b>RetretKu</b></h1>

<h3>Minimum Spec</h3>
Android API 22 : Android 5.1 Lollipop


<h3>Environtment</h3>
Android Studio 3.5
