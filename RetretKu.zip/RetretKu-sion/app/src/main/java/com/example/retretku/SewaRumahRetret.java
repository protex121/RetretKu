package com.example.retretku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;

import com.example.retretku.Object.Menu;
import com.example.retretku.Object.Paket;
import com.example.retretku.Object.Transaksi;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SewaRumahRetret extends AppCompatActivity {
    EditText etCin, etCout, etJumlah;
    Button btnSewa, btnAddPaket;
    RadioButton rbMakanan, rbSnack;
    Spinner spinPaket;
    ListView lvMenu;
    ArrayList<Paket> list_makanan, list_snack;
    ArrayList<String> id_makanan, id_snack, list_makanan_terpilih, list_snack_terpilih;
    ArrayAdapter adapter_paket, adapter_menu;
    String jenis = "";
    int index = -1, total = 0;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sewa_rumah_retret);

        etCin = findViewById(R.id.SewaRumahRetretDateIn);
        etCout = findViewById(R.id.SewaRumahRetretDateOut);
        etJumlah = findViewById(R.id.SewaRumahRetretJumlahPeserta);
        btnSewa = findViewById(R.id.SewaRumahRetretBtnSewa);
        btnAddPaket = findViewById(R.id.SewaRumahRetretBtnAddPaket);
        rbMakanan = findViewById(R.id.rbMakanan);
        rbSnack = findViewById(R.id.rbSnack);
        spinPaket = findViewById(R.id.spinPaket);
        lvMenu = findViewById(R.id.lvMenu);
        list_makanan = new ArrayList<>();
        list_snack = new ArrayList<>();
        list_makanan_terpilih = new ArrayList<>();
        list_snack_terpilih = new ArrayList<>();
        id_makanan = new ArrayList<>();
        id_snack = new ArrayList<>();

        mAuth = FirebaseAuth.getInstance();

        btnSewa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cin = etCin.getText().toString();
                String cout = etCout.getText().toString();
                String jumlah = etJumlah.getText().toString();
                String id_rumah_retret = getIntent().getStringExtra("id_rumah_retret");
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(mAuth.getUid()).child("Transaksi");
                Transaksi trans = new Transaksi(id_rumah_retret, cin, cout,Integer.parseInt(jumlah), (150000 + total) * Integer.parseInt(jumlah) , 0, list_makanan_terpilih, list_snack_terpilih);
                ref.setValue(trans);
                finish();
            }
        });

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Katering");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list_makanan.clear();
                list_snack.clear();
                id_makanan.clear();
                id_snack.clear();
                ArrayList<Paket> temp = new ArrayList<>();
                ArrayList<String> temp2 = new ArrayList<>();
                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    temp.add(d.getValue(Paket.class));
                    temp2.add(d.getKey());
                }
                for (int i = 0; i < temp.size(); i++) {
                    if(temp.get(i).getJenis().equals("Makanan")){
                        list_makanan.add(temp.get(i));
                        id_makanan.add(temp2.get(i));
                    }
                    else if(temp.get(i).getJenis().equals("Snack")){
                        list_snack.add(temp.get(i));
                        id_snack.add(temp2.get(i));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        rbMakanan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                jenis = "makanan";
                adapter_paket = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list_makanan);
                spinPaket.setAdapter(adapter_paket);
                spinPaket.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        index = i;
                        ArrayList<Menu> menu = list_makanan.get(i).getList_menu();
                        adapter_menu = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,menu);
                        lvMenu.setAdapter(adapter_menu);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
            }
        });

        rbSnack.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                jenis = "snack";
                adapter_paket = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list_snack);
                spinPaket.setAdapter(adapter_paket);
                spinPaket.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        index = i;
                        ArrayList<Menu> menu = list_snack.get(i).getList_menu();
                        adapter_menu = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,menu);
                        lvMenu.setAdapter(adapter_menu);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
            }
        });

        btnAddPaket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(jenis.equals("makanan")){
                    list_makanan_terpilih.add(id_makanan.get(index));
                    total += list_makanan.get(index).getHarga();
                }
                else if(jenis.equals("snack")){
                    list_snack_terpilih.add(id_snack.get(index));
                    total += list_snack.get(index).getHarga();
                }
            }
        });
    }
}
