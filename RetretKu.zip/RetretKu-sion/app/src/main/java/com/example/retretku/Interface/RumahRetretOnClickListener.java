package com.example.retretku.Interface;

import android.view.View;

public interface RumahRetretOnClickListener {
    void OnClick(View view, int position);
}
