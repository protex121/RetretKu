package com.example.retretku.Interface;

import android.view.View;

public interface ReportOnClickListener {
    void OnClick(View view, int position);
}
