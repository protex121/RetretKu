package com.example.retretku.Interface;

import android.view.View;

public interface UserOnClickListener {
    void OnClick(View view, int position);
}
