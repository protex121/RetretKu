package com.example.retretku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.retretku.Object.Katering;
import com.example.retretku.Object.Menu;
import com.example.retretku.Object.Paket;
import com.example.retretku.Object.RumahRetret;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminDetailKatering extends AppCompatActivity {
    TextView tvNama, tvAlamat, tvTelepon;
    Button btnBan;
    Spinner spinPaket;
    ListView lvMenu;
    ArrayList<Katering> list_katering;
    ArrayList<Paket> list_paket;
    ArrayList<Menu> list_menu;
    ArrayList<String> id;
    ArrayAdapter adapter_paket, adapter_menu;
    int index = -1;

    //Firebase
    FirebaseDatabase mDat;
    DatabaseReference mRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_detail_katering);
        tvNama = findViewById(R.id.detailKateringNama);
        btnBan = findViewById(R.id.detailKateringBan);
        tvAlamat = findViewById(R.id.detailKateringAlamat);
        tvTelepon = findViewById(R.id.detailKateringTelepon);
        spinPaket = findViewById(R.id.spinPaket);
        lvMenu = findViewById(R.id.lvPaket);
        list_katering = new ArrayList<>();
        list_menu = new ArrayList<>();
        list_paket = new ArrayList<>();

        Intent intent = getIntent();
        if(intent.hasExtra("index"))index = intent.getIntExtra("index",-1);

        //Atur Firebase
        mDat = FirebaseDatabase.getInstance();
        mRef = mDat.getReference("Katering");
        mRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list_katering.clear();
                id.clear();
                for (DataSnapshot temp : dataSnapshot.getChildren()){
                    Katering katering = temp.getValue(Katering.class);
                    list_katering.add(katering);
                    id.add(temp.getKey());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        tvNama.setText(list_katering.get(index).getNama_katering());
        tvAlamat.setText(list_katering.get(index).getAlamat());
        tvTelepon.setText(list_katering.get(index).getNomor_telpon());
        if(list_katering.get(index).getStat()==1)btnBan.setText("Disabled");
        else btnBan.setText("Enabled");

        //btnBan dengan Firebase
//        btnBan.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        if(list.get(index).getStatus()==1){
//                            DatabaseReference ganti = mRef.child("Katering").child(id.get(index)).child("katering_status");
//                            ganti.setValue(0);
//                        }
//                        else if(list.get(index).getStatus()==0){
//                            DatabaseReference ganti = mRef.child("Katering").child(id.get(index)).child("katering_status");
//                            ganti.setValue(1);
//                        }
//                    }
//                });

        //isi spinner
        ArrayList<Paket> temp = list_katering.get(index).getList_paket_makanan();
        list_paket.addAll(temp);
        temp = list_katering.get(index).getList_paket_snack();
        list_paket.addAll(temp);
        adapter_paket = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list_paket);
        spinPaket.setAdapter(adapter_paket);

        //isi menu
        spinPaket.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                list_menu = list_paket.get(i).getList_menu();
                adapter_menu = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list_menu);
                lvMenu.setAdapter(adapter_menu);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
