package com.example.retretku.Interface;

import android.view.View;

public interface KateringOnClickListener {
    void OnClick(View view, int position);
}
