package com.example.retretku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityCalendarDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_detail);
    }
}
